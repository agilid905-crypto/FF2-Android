package com.example.ff2prototype;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.Typeface;
import java.io.IOException;
import java.io.InputStream;

/** First visual/input test only. It is not the full Feeding Frenzy 2 engine. */
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) { super.onCreate(state); getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512); setContentView(new GameView()); }

  final class GameView extends View {
    Bitmap bg, ledge1, ledge2, overhang, fish;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    float fishX = 430, fishY = 390, targetX = 430, targetY = 390;
    long last = 0; float phase = 0;
    GameView() { super(MainActivity.this); try { bg=load("dribblecastle_background.jpg"); ledge1=load("dribblecastle_ledge_01.png"); ledge2=load("dribblecastle_ledge_02.png"); overhang=load("dribblecastle_overhang_01.png"); fish=load("butterflyfish_hudimage.png"); } catch(Exception e) {} setLayerType(View.LAYER_TYPE_HARDWARE,null); }
    Bitmap load(String n) throws IOException { InputStream in=getAssets().open(n); Bitmap b=BitmapFactory.decodeStream(in); in.close(); return b; }
    void drawImage(Canvas c, Bitmap b, float x, float y, float w, float h, boolean flip) { if(b==null)return; p.setAlpha(255); if(flip){ c.save(); c.scale(-1,1,x+w/2,y+h/2); c.drawBitmap(b,null,new RectF(x,y,x+w,y+h),p); c.restore(); } else c.drawBitmap(b,null,new RectF(x,y,x+w,y+h),p); }
    @Override protected void onDraw(Canvas c) { super.onDraw(c); float sx=getWidth()/1024f, sy=getHeight()/768f; c.save(); c.scale(sx,sy);
      if(bg!=null) drawImage(c,bg,0,0,1024,768,false); else c.drawColor(Color.rgb(0,110,160));
      // Approximate composition from the original backdrop XML; exact parallax/layout is still TODO.
      drawImage(c,overhang,70,-60,470,250,false); drawImage(c,overhang,720,-90,400,250,true);
      drawImage(c,ledge2,110,610,420,170,false); drawImage(c,ledge1,670,560,360,210,false);
      long now=System.nanoTime(); if(last!=0){float dt=Math.min(.05f,(now-last)/1e9f); fishX += (targetX-fishX)*Math.min(1,dt*5); fishY += (targetY-fishY)*Math.min(1,dt*5); phase += dt*6;} last=now;
      // HUD portrait is only a temporary placeholder; original animated actor stream is not decoded yet.
      c.save(); if(targetX<fishX) { c.scale(-1,1,fishX,fishY); } drawImage(c,fish,fishX-54,fishY-40,108,81,false); c.restore();
      p.setColor(Color.argb(180,0,18,40)); c.drawRoundRect(new RectF(18,16,435,84),14,14,p);
      p.setColor(Color.WHITE); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(23); c.drawText("FEEDING FRENZY 2 · NATIVE TEST",34,45,p);
      p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextSize(17); c.drawText("Touch anywhere to move the placeholder fish",34,69,p);
      c.restore(); postInvalidateDelayed(16);
    }
    @Override public boolean onTouchEvent(MotionEvent e) { float x=e.getX()*1024f/Math.max(1,getWidth()), y=e.getY()*768f/Math.max(1,getHeight()); if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){targetX=Math.max(45,Math.min(979,x)); targetY=Math.max(100,Math.min(690,y)); return true;} return true; }
  }
}
