# Feeding Frenzy 2 — Native Android prototype (0.1)

This is a **starter Android Studio project**, not a completed port and not a ready-to-install APK. It uses a small set of assets extracted from the user's `FF2.saf` upload for a first rendering and touch-input test.

## Included
- Original Stage 1 backdrop background and selected ledge/overhang images
- `butterflyfish/hudimage.png` as a temporary player marker
- Landscape Android Activity with a Canvas renderer and touch-to-move input

## Important limitations
- The fish is currently the small HUD portrait, **not** the animated gameplay sprite.
- The original `animation.theora` stream was not successfully decoded by the available standard media probe. The original animation XML defines `eat` (0–5, 32 fps), `idle` (6–17, 21 fps), `swim` (18–31, 66 fps), and `turn` (32–39, 34 fps); decoding/reconstruction is still required.
- Stage 1 backdrop layers are positioned approximately, not rendered with PopCap's exact layout/compositing system.
- No fish AI, eating/collision, growth, score, audio, level progression, save system, or final game logic is implemented yet.

## Build
Open this folder in Android Studio with Android SDK Platform 35 and a compatible JDK installed, then build the `app` debug variant. Alternatively, on a suitable Linux/Termux setup with Android SDK and Gradle configured, run:

```sh
gradle assembleDebug
```

The APK, if successfully built, will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Next technical milestone
Decode the actor animation stream and alpha masks into valid RGBA frame images, then replace the HUD portrait with the real gameplay animation. After that, implement stage-driven fish spawning and collision/eating logic.
